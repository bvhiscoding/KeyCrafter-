const jwt = require('jsonwebtoken');

const generateAccessToken = (userId) => jwt.sign({ id: userId }, process.env.JWT_ACCESS_SECRET, {
  expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m',
});

const generateRefreshToken = (userId) => jwt.sign({ id: userId }, process.env.JWT_REFRESH_SECRET, {
  expiresIn: process.env.JWT_REFRESH_EXPIRES || '7d',
});

const verifyToken = (token, secret) => jwt.verify(token, secret);

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyToken,
};
